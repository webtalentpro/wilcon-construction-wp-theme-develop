<?php
 
/**

 * @package wilcon plugin

 */
 
/*

Plugin Name: wilcon custom plugin



Description: Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from spam</strong>. It keeps your site protected even while you sleep. To get started: activate the Akismet plugin and then go to your Akismet Settings page to set up your API key.

Version: 1.0

Author: Aminul islam

Author URI: https://automattic.com/wordpress-plugins/

License: GPLv2 or later

Text Domain: wilcon

*/


function wilcon_custom_psot_type()
{
    register_post_type('services', array(
        'labels'=> array(
            'name'=>__('Service', 'wilcon'),
            'singular_name'=>__('Service', 'wilcon'),
            'add_new'=>__('New Service', 'wilcon'),
            'add_new_item'=>__('Service New Item', 'wilcon'),
            'edit_item'=>__('Edit Service', 'wilcon'),
            'view_item'=>__('View Service', 'wilcon'),
        ),
        'menu_icon'=> 'dashicons-screenoptions',
        'public'=> true,
        'menu_position'=> 4,
        'publicly_queryable'=> true,
        'exclude_from_search'=> true,
        'show_ui'=> true,
        'has_archive'=> true,
        'hierarchical' => true,
        'capability_type'=> 'post',
        'rewrite'=>array('slug'=>'service'),
        'supports'=> array('title', 'editor', 'thumbnail'),

        ));
    // Project post type
    register_post_type('projects', array(
            'labels'=> array(
                'name'=>__('Project', 'wilcon'),
                'singular_name'=>__('Project', 'wilcon'),
                'add_new'=>__('New project', 'wilcon'),
                'add_new_item'=>__('Project New Item', 'wilcon'),
                'edit_item'=>__('Edit Project', 'wilcon'),
                'view_item'=>__('View project', 'wilcon'),
            ),
            'menu_icon'=> 'dashicons-admin-multisite',
            'public'=> true,
            'menu_position'=> 6,
            'publicly_queryable'=> true,
            'exclude_from_search'=> true,
            'show_ui'=> true,
            'has_archive'=> true,
            'hierarchical' => true,
            'capability_type'=> 'post',
            'rewrite'=>array('slug'=>'project'),
            'supports'=> array('title', 'thumbnail'),
            ));

    // Team post type
    register_post_type('teams', array(
    'labels'=> array(
        'name'=>__('Team', 'wilcon'),
        'singular_name'=>__('Team', 'wilcon'),
        'add_new'=>__('New Team', 'wilcon'),
        'add_new_item'=>__('Team New Item', 'wilcon'),
        'edit_item'=>__('Edit Team', 'wilcon'),
        'view_item'=>__('View Team', 'wilcon'),
    ),
    'menu_icon'=> 'dashicons-groups',
    'public'=> true,
    'menu_position'=> 7,
    'publicly_queryable'=> true,
    'exclude_from_search'=> true,
    'show_ui'=> true,
    'has_archive'=> true,
    'hierarchical' => true,
    'capability_type'=> 'post',
    'rewrite'=>array('slug'=>'team'),
    'supports'=> array('title', 'editor'),
    ));
    // Team post type
    register_post_type('testimonials', array(
    'labels'=> array(
        'name'=>__('Testimonial', 'wilcon'),
        'singular_name'=>__('testimonial', 'wilcon'),
        'add_new'=>__('New testimonial', 'wilcon'),
        'add_new_item'=>__('testimonial New Item', 'wilcon'),
        'edit_item'=>__('Edit testimonial', 'wilcon'),
        'view_item'=>__('View testimonial', 'wilcon'),
    ),
    'menu_icon'=> 'dashicons-testimonial',
    'public'=> true,
    'menu_position'=> 8,
    'publicly_queryable'=> true,
    'exclude_from_search'=> true,
    'show_ui'=> true,
    'has_archive'=> true,
    'hierarchical' => true,
    'capability_type'=> 'post',
    'rewrite'=>array('slug'=>'team'),
    'supports'=> array('title', 'editor', 'thumbnail'),
    ));
}
add_action('init', 'wilcon_custom_psot_type');
